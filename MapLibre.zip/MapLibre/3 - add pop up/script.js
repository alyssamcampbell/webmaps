const mapInstance = new maplibregl.Map({
  container: 'map', // container id
  style: 'https://api.maptiler.com/maps/bdf82342-16c7-4da1-9d54-7a2c6ee417ff/style.json?key=FLpAkLhqyPdDd8wlHr1U', // style URL
  center: [2.3522, 48.856], // starting position [lng, lat]
  zoom: 5, // starting zoom
  hash: true
});

const journeyCoordinates = [
  ["City 1", 47.63391466771252, -122.52729914415487, "description 1"], // Bainbridge Island
  ["City 2", 47.66159670798355, -122.30817094085475, "description 2"], // Seattle
  ["City 3", 37.80444424121187, -122.43827589048583, "description 3"], // San Francisco
];

function addSourceAndLayer(map) {
  map.addSource('points', {
    type: 'geojson',
    data: {
      type: 'FeatureCollection',
      features: journeyCoordinates.map(function (coord) {
        return {
          type: 'Feature',
          geometry: {
            type: 'Point',
            coordinates: [coord[2], coord[1]] // Swap lat and long positions
          },
          properties: {
            name: coord[0],
            description: coord[3]
          }
        };
      })
    }
  });

  map.addLayer({
    id: 'journey', // Unique ID for the layer
    source: 'points',
    type: 'circle',
    paint: {
      'circle-color': '#68f',
      'circle-stroke-width': 1,
      'circle-stroke-color': '#fff'
    }
  });

  let popup;

  map.on('mousemove', 'journey', function (e) {
    var coordinates = e.features[0].geometry.coordinates.slice();
    var properties = e.features[0].properties;
  
    if (popup) {
      popup.remove();
    }
  
    popup = new maplibregl.Popup()
      .setLngLat(coordinates)
      .setHTML(`<h3>${properties.name}</h3><p>${properties.description}</p>`)
      .addTo(map);
  });
  
  map.on('mouseleave', 'journey', function () {
    if (popup) {
      popup.remove();
      popup = undefined;
    }
  });
}

function initializeMap() {
  mapInstance.on('load', function () {
    addSourceAndLayer(mapInstance);
  });
}

initializeMap();
