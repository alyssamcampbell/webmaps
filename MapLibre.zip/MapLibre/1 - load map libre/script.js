const map = new maplibregl.Map({
    container: 'map', // container id
    style: 'https://api.maptiler.com/maps/bdf82342-16c7-4da1-9d54-7a2c6ee417ff/style.json?key=FLpAkLhqyPdDd8wlHr1U', // style URL
    center: [2.3522, 48.856], // starting position [lng, lat]
    zoom: 12, // starting zoom
    hash: true
});

