const map = new maplibregl.Map({
  container: 'map', // container id
  style: 'https://api.maptiler.com/maps/bdf82342-16c7-4da1-9d54-7a2c6ee417ff/style.json?key=FLpAkLhqyPdDd8wlHr1U', // style URL
  center: [2.3522, 48.856], // starting position [lng, lat]
  zoom: 5, // starting zoom
  hash: true
});

const journeyCoordinates = [
  ["City 1", 47.63391466771252, -122.52729914415487, "description 1"], // Bainbridge Island
  ["City 2", 47.66159670798355, -122.30817094085475, "description 2"], // Seattle
  ["City 3", 37.80444424121187, -122.43827589048583, "description 3"], // San Francisco
];

const geojson = {
  'type': 'FeatureCollection',
  'features': [{
    'type': 'Feature',
    'geometry': {
      'type': 'LineString',
      'coordinates': []
    }
  }]
};

const speedFactor = 30; // number of frames per longitude degree
let animation; // to store and cancel the animation
let startTime = 0;
let progress = 0; // progress = timestamp - startTime
let resetTime = false; // indicator of whether time reset is needed for the animation

map.on('load', () => {
  map.addSource('line', {
    'type': 'geojson',
    'data': geojson
  });

  // add the line which will be modified in the animation
  map.addLayer({
    'id': 'line-animation',
    'type': 'line',
    'source': 'line',
    'layout': {
      'line-cap': 'round',
      'line-join': 'round'
    },
    'paint': {
      'line-color': '#ed6498',
      'line-width': 5,
      'line-opacity': 0.8
    }
  });

  startTime = performance.now();

  animateLine();

  const pauseButton = document.getElementById('pause');

  // click the button to pause or play
  pauseButton.addEventListener('click', () => {
    pauseButton.classList.toggle('pause');
    if (pauseButton.classList.contains('pause')) {
      cancelAnimationFrame(animation);
    } else {
      resetTime = true;
      animateLine();
    }
  });

  // reset startTime and progress once the tab loses or gains focus
  // requestAnimationFrame also pauses on hidden tabs by default
  document.addEventListener('visibilitychange', () => {
    resetTime = true;
  });

  function animateLine(timestamp) {
    if (resetTime) {
      startTime = performance.now() - progress;
      resetTime = false;
    } else {
      progress = timestamp - startTime;
    }

    if (progress > speedFactor * 300) {
      startTime = timestamp;
      geojson.features[0].geometry.coordinates = [];
    } else {
      const index = Math.floor(progress / speedFactor);
      
      if (index < journeyCoordinates.length) {
        const coordinate = journeyCoordinates[index];
        const lng = coordinate[2];
        const lat = coordinate[1];
        const description = coordinate[3];
        
        geojson.features[0].geometry.coordinates.push([lng, lat]);
        map.getSource('line').setData(geojson);

        new maplibregl.Popup()
          .setLngLat([lng, lat])
          .setHTML(`<b>${coordinate[0]}</b><br>${description}`)
          .addTo(map);
      }
    }

    animation = requestAnimationFrame(animateLine);
  }
});
