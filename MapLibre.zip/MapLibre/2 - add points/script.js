const mapInstance = new maplibregl.Map({
  container: 'map', // container id
  style: 'https://api.maptiler.com/maps/bdf82342-16c7-4da1-9d54-7a2c6ee417ff/style.json?key=FLpAkLhqyPdDd8wlHr1U', // style URL
  center: [2.3522, 48.856], // starting position [lng, lat]
  zoom: 5, // starting zoom
  hash: true
});

const journeyCoordinates = [
  [-122.52729914415487, 47.63391466771252], // Bainbridge Island
  [-122.30817094085475, 47.66159670798355], // Seattle
  [-122.43827589048583, 37.80444424121187], // San Francisco
  [-73.99780825980085, 40.73112646783126], // New York
  [-73.78867535842312, 40.64338871425513], // New York JFK
  [34.770466821168405, 32.08807693740594], // Tel Aviv
  [28.97784715618639, 41.00894863216677], // Istanbul
  [72.87981284881647, 19.088415322843208], // Mumbai
  [77.58974074657802, 12.982770072181893], // Bangalore
  [79.83069418643692, 11.936883123451027], // Pondicherry
  [99.00470953038322, 18.97307603337172] // Chiang Mai
];

function addSourceAndLayer(map) {
  map.addSource('points', {
    type: 'geojson',
    data: {
      type: 'FeatureCollection',
      features: journeyCoordinates.map(function (coord) {
        return {
          type: 'Feature',
          geometry: {
            type: 'Point',
            coordinates: coord
          }
        };
      })
    }
  });

  map.addLayer({
    id: 'hjourney', // Unique ID for the layer
    source: 'points',
    type: 'circle',
    paint: {
      'circle-color': '#68f',
      'circle-stroke-width': 1,
      'circle-stroke-color': '#fff'
    }
  });
}

function initializeMap() {
  mapInstance.on('load', function () {
    addSourceAndLayer(mapInstance);
  });
}

initializeMap();